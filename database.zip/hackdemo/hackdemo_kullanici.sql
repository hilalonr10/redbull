-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hackdemo
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kullanici`
--

DROP TABLE IF EXISTS `kullanici`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kullanici` (
  `kull_id` int NOT NULL AUTO_INCREMENT,
  `kull_ad` varchar(50) NOT NULL,
  `kull_mail` varchar(50) NOT NULL,
  `kull_sifre` varchar(50) NOT NULL,
  `kull_il_id` int DEFAULT NULL,
  `kull_ilce_id` int DEFAULT NULL,
  PRIMARY KEY (`kull_id`),
  KEY `kullil_idx` (`kull_il_id`),
  KEY `kullilce_idx` (`kull_ilce_id`),
  CONSTRAINT `kullil` FOREIGN KEY (`kull_il_id`) REFERENCES `il` (`il_id`),
  CONSTRAINT `kullilce` FOREIGN KEY (`kull_ilce_id`) REFERENCES `ilce` (`ilce_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kullanici`
--

LOCK TABLES `kullanici` WRITE;
/*!40000 ALTER TABLE `kullanici` DISABLE KEYS */;
INSERT INTO `kullanici` VALUES (1,'Bedirhan ÇAKAR','Bedirhan@gmail.com','1234',13,206),(2,'Miraç','Miraç@gmail.com','1234',72,910),(3,'fatma','fatma33@gmail.com','741',33,444),(4,'admin','adminnn@gmail.com','123456',72,NULL),(5,'hilaloner','hllonr45@gmail.com','123456',72,NULL),(6,'mert','mert@gmail.com','123456',45,NULL),(7,'fatmanur yardım','ftmnr13@gmail.com','123456',13,206),(8,'mustafa','mustafa45@gmail.com','123456',39,NULL),(9,'ahmet','ahmet42@gmail.com','123456',61,815);
/*!40000 ALTER TABLE `kullanici` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-29  6:38:24
