-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hackdemo
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('1xxov9he02m7gpl8nyw6wzy3yh6u6ltv','.eJxVjMEOgjAQRP-lZ9O0CwvFo3e-odl2F4uaklA4Gf_dknDQ48x7M2_lad-S34usfmZ1VVZdfrtA8Sn5APygfF90XPK2zkEfij5p0ePC8rqd7t9BopLqegoAzjphaAYM2EsNExsRA7HrB3QMDC4YdLYla0xjKdoOsHIkaVF9vs_pNwE:1s1HaD:5tAX1qwSqbrIu_JXCjAxKw0s5rJx6WzNEmVWq9HWruc','2024-05-13 03:21:37.608932'),('42oiunobn73s2bbw7qmq1oe11iybhcip','e30:1s1242:1bWW8xeofwwlUdZ7mxR3jJ8Vfg3NP9-AqQjjrEDIxBo','2024-05-12 10:47:22.972999'),('bbn0ompx0720tnq4k4cxsy37fco6corw','.eJxVjMEOgjAQRP-lZ9O0CwvFo3e-odl2F4uaklA4Gf_dknDQ48x7M2_lad-S34usfmZ1VVZdfrtA8Sn5APygfF90XPK2zkEfij5p0ePC8rqd7t9BopLqegoAzjphaAYM2EsNExsRA7HrB3QMDC4YdLYla0xjKdoOsHIkaVF9vs_pNwE:1s13RW:XCWFkZHD1FKwiSoYgfIYoKwtQuPXmP5XVTbNft0vc6c','2024-05-12 12:15:42.839110'),('cwcs9vumjom2dxifonanww39fole9c80','e30:1s1213:UgjozvsRflhP9eCH1nT1d3Yw1E_MXMz-NvdPhHt3OR4','2024-05-12 10:44:17.481108'),('thkma226oih1oz4y7799mqghw2qnwka9','e30:1s126y:m4nYkownykuvH1hCo2dsLl_-SwUS4E_xWGYLOuTz2VI','2024-05-12 10:50:24.884499');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-29  6:38:24
